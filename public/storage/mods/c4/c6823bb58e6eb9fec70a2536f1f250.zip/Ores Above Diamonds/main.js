IMPORT("ToolType");
IDRegistry.genItemID("amethyst_helmet");
Item.createArmorItem("amethyst_helmet", "amethyst_helmet", {name: "amethyst_helmet"}, {type: "helmet", armor: 5, durability: 2500, texture: "armor/amethyst_layer_1"});
IDRegistry.genItemID("amethyst_chestplate");
Item.createArmorItem("amethyst_chestplate", "amethyst_chestplate", {name: "amethyst_chestplate"}, {type: "chestplate", armor: 7, durability: 2500, texture: "armor/amethyst_layer_1"});
IDRegistry.genItemID("amethyst_leggings");
Item.createArmorItem("amethyst_leggings", "amethyst_leggings", {name: "amethyst_leggings"}, {type: "leggings", armor: 6, durability: 2500, texture: "armor/amethyst_layer_2"});
IDRegistry.genItemID("amethyst_boots");
Item.createArmorItem("amethyst_boots", "amethyst_boots", {name: "amethyst_boots"}, {type: "boots", armor: 5, durability: 2500, texture: "armor/amethyst_layer_1"});
IDRegistry.genItemID("black_opal");
Item.createItem("black_opal", "black_opal", {name: "black_opal", meta: 0}, {stack: 64});
IDRegistry.genItemID("amethyst");
Item.createItem("amethyst", "amethyst", {name: "amethyst", meta: 0}, {stack: 64});
//amethyst_sword
ToolAPI.addToolMaterial("amethyst_sword", {     durability: 2000, level: 1, efficiency: 1,    damage: 8, enchantability: 100 });
IDRegistry.genItemID("amethyst_sword");
Item.createItem("amethyst_sword", "amethyst_sword", {name: "amethyst_sword", meta: 0}, {stack: 1}); ToolAPI.setTool(ItemID["amethyst_sword"], "amethyst_sword", ToolType.sword);
//axe
ToolAPI.addToolMaterial("amethyst_axe", {     durability: 2000, level: 1, efficiency: 7,    damage: 10, enchantability: 100 });
IDRegistry.genItemID("amethyst_axe");
Item.createItem("amethyst_axe", "amethyst_axe", {name: "amethyst_axe", meta: 0}, {stack: 1}); ToolAPI.setTool(ItemID["amethyst_axe"], "amethyst_axe", ToolType.axe);
//pickaxe
ToolAPI.addToolMaterial("amethyst_pickaxe", {     durability: 2000, level: 7, efficiency: 4,    damage: 6, enchantability: 100 });
IDRegistry.genItemID("amethyst_pickaxe");
Item.createItem("amethyst_pickaxe", "amethyst_pickaxe", {name: "amethyst_pickaxe", meta: 0}, {stack: 1}); ToolAPI.setTool(ItemID["amethyst_pickaxe"], "amethyst_pickaxe", ToolType.pickaxe);
//hoe
ToolAPI.addToolMaterial("amethyst_hoe", {     durability: 2000, level: 1, efficiency: 1,    damage: 5, enchantability: 100 });
IDRegistry.genItemID("amethyst_hoe");
Item.createItem("amethyst_hoe", "amethyst_hoe", {name: "amethyst_hoe", meta: 0}, {stack: 1}); ToolAPI.setTool(ItemID["amethyst_hoe"], "amethyst_hoe", ToolType.hoe);
//shovel
ToolAPI.addToolMaterial("amethyst_shovel", {     durability: 2000, level: 1, efficiency: 7,    damage: 7, enchantability: 100 });
IDRegistry.genItemID("amethyst_shovel");
Item.createItem("amethyst_shovel", "amethyst_shovel", {name: "amethyst_shovel", meta: 0}, {stack: 1}); ToolAPI.setTool(ItemID["amethyst_shovel"], "amethyst_shovel", ToolType.shovel);
//руда аметиста и её дроп
var BLOCK_TYPE_STONE = Block.createSpecialType({ 	base: 1, 	solid: true, 	destroytime: 2, 	explosionres: 2 }, "stone"); IDRegistry.genBlockID("amethyst_ore"); Block.createBlock("amethyst_ore", [ 	{name: "amethyst_ore", texture: [["amethyst_ore", 0]], inCreative: true} ], BLOCK_TYPE_STONE); ToolAPI.registerBlockMaterial(BlockID.amethyst_ore, "stone", 0, true); Block.registerDropFunction("amethyst_ore", function(coords, blockID, blockData, level, enchant){ 	if(level > 3){ 		if(enchant.silk){ 			return [[blockID, 1, 0]]; 		} 		ToolAPI.dropOreExp(coords, 3, 7, enchant.experience); 		return [[ItemID.amethyst, 2, 0]] 	} 	return []; }, 3);
//руда опала и её дроп
var BLOCK_TYPE_STONE = Block.createSpecialType({ 	base: 1, 	solid: true, 	destroytime: 2, 	explosionres: 2 }, "stone"); IDRegistry.genBlockID("black_opal_ore"); Block.createBlock("black_opal_ore", [ 	{name: "black_opal_ore", texture: [["black_opal_ore", 0]], inCreative: true} ], BLOCK_TYPE_STONE); ToolAPI.registerBlockMaterial(BlockID.black_opal_ore, "stone", 0, true); Block.registerDropFunction("black_opal_ore", function(coords, blockID, blockData, level, enchant){ 	if(level > 6){ 		if(enchant.silk){ 			return [[blockID, 1, 0]]; 		} 		ToolAPI.dropOreExp(coords, 3, 7, enchant.experience); 		return [[ItemID.black_opal, 2, 0]] 	} 	return []; }, 3);
//эффекты
Callback.addCallback("tick", function () { 
var helmet = Player.getArmorSlot(0);
var chestplate = Player.getArmorSlot(1);
var leggings = Player.getArmorSlot(2);
var boots = Player.getArmorSlot(3);

if(helmet.id==ItemID.amethyst_helmet&&chestplate.id==ItemID.amethyst_chestplate&&leggings.id==ItemID.amethyst_leggings&&boots.id==ItemID.amethyst_boots){
	Entity.addEffect(Player.get(), 22, 2, 100, false)
}});

Callback.addCallback("tick", function () { 
var helmet = Player.getArmorSlot(0);
var chestplate = Player.getArmorSlot(1);
var leggings = Player.getArmorSlot(2);
var boots = Player.getArmorSlot(3);

if(helmet.id==ItemID.amethyst_helmet&&chestplate.id==ItemID.amethyst_chestplate&&leggings.id==ItemID.amethyst_leggings&&boots.id==ItemID.amethyst_boots){
	Entity.addEffect(Player.get(), 13, 2, 100, false)
}});
Callback.addCallback("tick", function () { 
var helmet = Player.getArmorSlot(0);
var chestplate = Player.getArmorSlot(1);
var leggings = Player.getArmorSlot(2);
var boots = Player.getArmorSlot(3);

if(helmet.id==ItemID.amethyst_helmet&&chestplate.id==ItemID.amethyst_chestplate&&leggings.id==ItemID.amethyst_leggings&&boots.id==ItemID.amethyst_boots){
	Entity.addEffect(Player.get(), 22, 2, 100, false)
}});
Callback.addCallback("tick", function () { 
var helmet = Player.getArmorSlot(0);
var chestplate = Player.getArmorSlot(1);
var leggings = Player.getArmorSlot(2);
var boots = Player.getArmorSlot(3);

if(helmet.id==ItemID.amethyst_helmet&&chestplate.id==ItemID.amethyst_chestplate&&leggings.id==ItemID.amethyst_leggings&&boots.id==ItemID.amethyst_boots){
	Entity.addEffect(Player.get(), 10, 2, 100, false)
}});
//броня из опала
IDRegistry.genItemID("black_opal_helmet");
Item.createArmorItem("black_opal_helmet", "black_opal_helmet", {name: "black_opal_helmet"}, {type: "helmet", armor: 10, durability: 5000, texture: "armor/black_opal_layer_1"});
IDRegistry.genItemID("black_opal_chestplate");
Item.createArmorItem("black_opal_chestplate", "black_opal_chestplate", {name: "black_opal_chestplate"}, {type: "chestplate", armor: 13, durability: 5000, texture: "armor/black_opal_layer_1"});
IDRegistry.genItemID("black_opal_leggings");
Item.createArmorItem("black_opal_leggings", "black_opal_leggings", {name: "black_opal_leggings"}, {type: "leggings", armor: 12, durability: 5000, texture: "armor/black_opal_layer_2"});
IDRegistry.genItemID("black_opal_boots");
Item.createArmorItem("black_opal_boots", "black_opal_boots", {name: "black_opal_boots"}, {type: "boots", armor: 9, durability: 5000, texture: "armor/black_opal_layer_1"});
//эффекты
Callback.addCallback("tick", function () { 
var helmet = Player.getArmorSlot(0);
var chestplate = Player.getArmorSlot(1);
var leggings = Player.getArmorSlot(2);
var boots = Player.getArmorSlot(3);

if(helmet.id==ItemID.black_opal_helmet&&chestplate.id==ItemID.black_opal_chestplate&&leggings.id==ItemID.black_opal_leggings&&boots.id==ItemID.black_opal_boots){
	Entity.addEffect(Player.get(), 1, 1, 100, false)
}});
Callback.addCallback("tick", function () { 
var helmet = Player.getArmorSlot(0);
var chestplate = Player.getArmorSlot(1);
var leggings = Player.getArmorSlot(2);
var boots = Player.getArmorSlot(3);

if(helmet.id==ItemID.black_opal_helmet&&chestplate.id==ItemID.black_opal_chestplate&&leggings.id==ItemID.black_opal_leggings&&boots.id==ItemID.black_opal_boots){
	Entity.addEffect(Player.get(), 12, 1, 100, false)
}});
Callback.addCallback("tick", function () { 
var helmet = Player.getArmorSlot(0);
var chestplate = Player.getArmorSlot(1);
var leggings = Player.getArmorSlot(2);
var boots = Player.getArmorSlot(3);

if(helmet.id==ItemID.black_opal_helmet&&chestplate.id==ItemID.black_opal_chestplate&&leggings.id==ItemID.black_opal_leggings&&boots.id==ItemID.black_opal_boots){
	Entity.addEffect(Player.get(), 16, 1, 100, false)
}});
//sword
ToolAPI.addToolMaterial("black_opal_sword", {     durability: 4000, level: 1, efficiency: 1,    damage: 9, enchantability: 100 });
IDRegistry.genItemID("black_opal_sword");
Item.createItem("black_opal_sword", "black_opal_sword", {name: "black_opal_sword", meta: 0}, {stack: 1}); ToolAPI.setTool(ItemID["black_opal_sword"], "black_opal_sword", ToolType.sword);
//axe
ToolAPI.addToolMaterial("black_opal_axe", {     durability: 4000, level: 1, efficiency: 9,    damage: 11, enchantability: 100 });
IDRegistry.genItemID("black_opal_axe");
Item.createItem("black_opal_axe", "black_opal_axe", {name: "black_opal_axe", meta: 0}, {stack: 1}); ToolAPI.setTool(ItemID["black_opal_axe"], "black_opal_axe", ToolType.axe);
//pickaxe
ToolAPI.addToolMaterial("black_opal_pickaxe", {     durability: 4000, level: 7, efficiency: 6,    damage: 8, enchantability: 100 });
IDRegistry.genItemID("black_opal_pickaxe");
Item.createItem("black_opal_pickaxe", "black_opal_pickaxe", {name: "black_opal_pickaxe", meta: 0}, {stack: 1}); ToolAPI.setTool(ItemID["black_opal_pickaxe"], "black_opal_pickaxe", ToolType.pickaxe);
//hoe
ToolAPI.addToolMaterial("black_opal_hoe", {     durability: 4000, level: 1, efficiency: 1,    damage: 6, enchantability: 100 });
IDRegistry.genItemID("black_opal_hoe");
Item.createItem("black_opal_hoe", "black_opal_hoe", {name: "black_opal_hoe", meta: 0}, {stack: 1}); ToolAPI.setTool(ItemID["black_opal_hoe"], "black_opal_hoe", ToolType.hoe);
//shovel
ToolAPI.addToolMaterial("black_opal_shovel", {     durability: 4000, level: 1, efficiency: 9,    damage: 8, enchantability: 100 });
IDRegistry.genItemID("black_opal_shovel");
Item.createItem("black_opal_shovel", "black_opal_shovel", {name: "black_opal_shovel", meta: 0}, {stack: 1}); ToolAPI.setTool(ItemID["black_opal_shovel"], "black_opal_shovel", ToolType.shovel);
//блок аметиста
var BLOCK_TYPE_STONE = Block.createSpecialType({ 	base: 1, 	solid: true, 	destroytime: 2, 	explosionres: 2 }, "stone"); IDRegistry.genBlockID("amethyst_block"); Block.createBlock("amethyst_block", [ 	{name: "amethyst_block", texture: [["amethyst_block", 0]], inCreative: true} ], BLOCK_TYPE_STONE); ToolAPI.registerBlockMaterial(BlockID.amethyst_block, "stone", 0, true);
Block.registerDropFunction("amethyst_block", function(coords, blockID, blockData, level, enchant){ 	if(level > 0){ 		if(enchant.silk){ 			return [[blockID, 1, 0]]; 		} 		 		return [[BlockID.amethyst_block, 1, 0]] 	} 	return []; }, 3);
//блок из опала
var BLOCK_TYPE_STONE = Block.createSpecialType({ 	base: 1, 	solid: true, 	destroytime: 2, 	explosionres: 2 }, "stone"); IDRegistry.genBlockID("black_opal_block"); Block.createBlock("black_opal_block", [ 	{name: "black_opal_block", texture: [["black_opal_block", 0]], inCreative: true} ], BLOCK_TYPE_STONE); ToolAPI.registerBlockMaterial(BlockID.black_opal_block, "stone", 0, true);
Block.registerDropFunction("black_opal_block", function(coords, blockID, blockData, level, enchant){ 	if(level > 0){ 		if(enchant.silk){ 			return [[blockID, 1, 0]]; 		} 		 		return [[BlockID.black_opal_block, 1, 0]] 	} 	return []; }, 3);
//перевод на русский язык
Translation.addTranslation("black_opal_block", {ru: "Опаловый блок"});

Translation.addTranslation("black_opal_block", {ru: "Опаловый блок"});

Translation.addTranslation("black_opal_block", {ru: "Опаловый блок"});

Translation.addTranslation("black_opal_block", {ru: "Опаловый блок"});

Translation.addTranslation("amethyst_pickaxe", {ru: "Аметистовая кирка"});

Translation.addTranslation("amethyst_shovel", {ru: "Аметистовая лопата"});

Translation.addTranslation("amethyst_sword", {ru: "Аметистовый меч"});

Translation.addTranslation("amethyst_hoe", {ru: "Аметистовая мотыга"});

Translation.addTranslation("amethyst_axe", {ru: "Аметистовый топор"});

Translation.addTranslation("black_opal", {ru: "Опал"});

Translation.addTranslation("amethyst", {ru: "Аметист"});

Translation.addTranslation("amethyst_ore", {ru: "Аметистовая руда"});

Translation.addTranslation("amethyst_helmet", {ru: "Аметистовый шлем"});

Translation.addTranslation("amethyst_chestplate", {ru: "Аметистовый нагрудник"});

Translation.addTranslation("amethyst_leggings", {ru: "Аметистовые штаны"});

Translation.addTranslation("amethyst_boots", {ru: "Аметистовые ботинки"});

Translation.addTranslation("black_opal_helmet", {ru: "Опаловый шлем"});

Translation.addTranslation("black_opal_boots", {ru: "Опаловые ботинки"});

Translation.addTranslation("black_opal_chestplate", {ru: "Опаловый нагрудник"});

Translation.addTranslation("black_opal_leggings", {ru: "Опаловые штаны"});

Translation.addTranslation("black_opal_pickaxe", {ru: "Опаловая кирка"});

Translation.addTranslation("black_opal_hoe", {ru: "Опаловая мотыга"});

Translation.addTranslation("black_opal_axe", {ru: "Опаловый топор"});

Translation.addTranslation("black_opal_sword", {ru: "Опаловый меч"});

Translation.addTranslation("black_opal_shovel", {ru: "Опаловая лопата"});

Translation.addTranslation("black_opal_ore", {ru: "Опаловая руда"});

Translation.addTranslation("amethyst_block", {ru: "Аметистовый блок"});
//крафты
//中文翻译
Translation.addTranslation("black_opal_block", {zh: "黑色欧泊块"});
Translation.addTranslation("black_opal_block", {zh: "黑色欧泊块"});
Translation.addTranslation("black_opal_block", {zh: "黑色欧泊块"});
Translation.addTranslation("black_opal_block", {zh: "黑色欧泊块"});
Translation.addTranslation("amethyst_pickaxe", {zh: "紫晶镐"});
Translation.addTranslation("amethyst_shovel", {zh: "紫晶铲"});
Translation.addTranslation("amethyst_sword", {zh: "紫晶剑"});
Translation.addTranslation("amethyst_hoe", {zh: "紫晶锄"});
Translation.addTranslation("amethyst_axe", {zh: "紫晶斧"});
Translation.addTranslation("black_opal", {zh: "黑欧泊"});
Translation.addTranslation("amethyst", {zh: "紫晶"});
Translation.addTranslation("amethyst_ore", {zh: "紫晶矿"});
Translation.addTranslation("amethyst_helmet", {zh: "紫晶头盔"});
Translation.addTranslation("amethyst_chestplate", {zh: "紫晶甲"});
Translation.addTranslation("amethyst_leggings", {zh: "紫晶护腿"});
Translation.addTranslation("amethyst_boots", {zh: "紫晶靴"});
Translation.addTranslation("black_opal_helmet", {zh: "黑欧泊头盔"});
Translation.addTranslation("black_opal_boots", {zh: "黑欧泊靴"});
Translation.addTranslation("black_opal_chestplate", {zh: "黑欧泊甲"});
Translation.addTranslation("black_opal_leggings", {zh: "黑欧泊护腿"});
Translation.addTranslation("black_opal_pickaxe", {zh: "黑欧泊镐"});
Translation.addTranslation("black_opal_hoe", {zh: "黑欧泊锄"});
Translation.addTranslation("black_opal_axe", {zh: "黑欧泊斧"});
Translation.addTranslation("black_opal_sword", {zh: "黑欧泊剑"});
Translation.addTranslation("black_opal_shovel", {zh: "黑欧泊铲"});
Translation.addTranslation("black_opal_ore", {zh: "黑色欧泊矿"});
Translation.addTranslation("amethyst_block", {zh: "紫晶块"});
//中文翻译
Recipes.addShaped({id: BlockID.amethyst_block, count: 1, data: 0}, [
 "aaa",
 "aaa",
 "aaa"
], ['a', ItemID.amethyst, 0]);

Recipes.addShaped({id: ItemID.black_opal_pickaxe, count: 1, data: 0}, [
 "aaa",
 " b ",
 " b "
], ['a', ItemID.black_opal, 0, 'b', 280, 0]);

Recipes.addShaped({id: BlockID.black_opal_block, count: 1, data: 0}, [
 "aaa",
 "aaa",
 "aaa"
], ['a', ItemID.black_opal, 0]);

Recipes.addShaped({id: ItemID.black_opal_sword, count: 1, data: 0}, [
 " a ",
 " a ",
 " b "
], ['a', ItemID.black_opal, 0, 'b', 280, 0]);

Recipes.addShaped({id: ItemID.black_opal_shovel, count: 1, data: 0}, [
 " a ",
 " b ",
 " b "
], ['a', ItemID.black_opal, 0, 'b', 280, 0]);

Recipes.addShaped({id: ItemID.black_opal_axe, count: 1, data: 0}, [
 " aa",
 " ba",
 " b "
], ['a', ItemID.black_opal, 0, 'b', 280, 0]);

Recipes.addShaped({id: ItemID.black_opal_hoe, count: 1, data: 0}, [
 " aa",
 " b ",
 " b "
], ['a', ItemID.black_opal, 0, 'b', 280, 0]);

Recipes.addShaped({id: ItemID.amethyst_pickaxe, count: 1, data: 0}, [
 "aaa",
 " b",
 " b"
], ['a', ItemID.amethyst, 0, 'b', 280, 0]);

Recipes.addShaped({id: ItemID.amethyst_sword, count: 1, data: 0}, [
 " a ",
 " a ",
 " b "
], ['a', ItemID.amethyst, 0, 'b', 280, 0]);

Recipes.addShaped({id: ItemID.amethyst_shovel, count: 1, data: 0}, [
 " a ",
 " b ",
 " b "
], ['a', ItemID.amethyst, 0, 'b', 280, 0]);

Recipes.addShaped({id: ItemID.amethyst_hoe, count: 1, data: 0}, [
 " aa",
 " b ",
 " b "
], ['a', ItemID.amethyst, 0, 'b', 280, 0]);

Recipes.addShaped({id: ItemID.amethyst_axe, count: 1, data: 0}, [
 " aa",
 " ba",
 " b "
], ['a', ItemID.amethyst, 0, 'b', 280, 0]);

Recipes.addShaped({id: ItemID.amethyst_chestplate, count: 1, data: 0}, [
 "a a",
 "aaa",
 "aaa"
], ['a', ItemID.amethyst, 0]);

Recipes.addShaped({id: ItemID.amethyst_leggings, count: 1, data: 0}, [
 "aaa",
 "a a",
 "a a"
], ['a', ItemID.amethyst, 0]);

Recipes.addShaped({id: ItemID.amethyst_helmet, count: 1, data: 0}, [
 "aaa",
 "a a",
 "   "
], ['a', ItemID.amethyst, 0]);

Recipes.addShaped({id: ItemID.amethyst_boots, count: 1, data: 0}, [
 "",
 "a a",
 "a a"
], ['a', ItemID.amethyst, 0]);

Recipes.addShaped({id: ItemID.black_opal_chestplate, count: 1, data: 0}, [
 "a a",
 "aaa",
 "aaa"
], ['a', ItemID.black_opal, 0]);

Recipes.addShaped({id: ItemID.black_opal_leggings, count: 1, data: 0}, [
 "aaa",
 "a a",
 "a a"
], ['a', ItemID.black_opal, 0]);

Recipes.addShaped({id: ItemID.black_opal_helmet, count: 1, data: 0}, [
 "aaa",
 "a a",
 "   "
], ['a', ItemID.black_opal, 0]);

Recipes.addShaped({id: ItemID.black_opal_boots, count: 1, data: 0}, [
 "",
 "a a",
 "a a"
], ['a', ItemID.black_opal, 0]);
//генерация руды
Callback.addCallback("GenerateChunkUnderground", function(chunkX, chunkZ){ var coords = GenerationUtils.randomCoords(chunkX, chunkZ, 4, 13); for (var q = 0; q < 15;q++){ if (Math.random() < 7/10) GenerationUtils.genMinable(coords.x, coords.y, coords.z, { id: BlockID.amethyst_ore, data: 0, size: 4, ratio: .3, checkerTile: 1, checkerMode: false }); } });﻿

Callback.addCallback("GenerateChunkUnderground", function(chunkX, chunkZ){ var coords = GenerationUtils.randomCoords(chunkX, chunkZ, 3, 13); for (var q = 0; q < 15;q++){ if (Math.random() < 7/10) GenerationUtils.genMinable(coords.x, coords.y, coords.z, { id: BlockID.black_opal_ore, data: 0, size: 4, ratio: .3, checkerTile: 1, checkerMode: false }); } });﻿