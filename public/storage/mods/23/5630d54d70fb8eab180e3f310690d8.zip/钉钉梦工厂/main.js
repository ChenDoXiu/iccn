
/*
BUILD INFO:
  dir: dev
  target: main.js
  files: n
*/
//钉钉块
IDRegistry.genBlockID("钉钉块");
Block.createBlockWithRotation("钉钉块", [
	{name: "钉钉块", texture: [["钉钉块", 0], ["钉钉块", 0], ["钉钉块", 0], ["钉钉块", 0], ["钉钉块", 0], ["钉钉块", 0]], inCreative: true}
]);
ToolAPI.registerBlockMaterial(BlockID.钉钉块, "stone");


//食物
IDRegistry.genItemID("钉钉糖");
Item.createFoodItem("钉钉糖", "钉钉糖", {name:"钉钉糖"}, {food:4});


Recipes.addShaped({id: ItemID.钉钉糖, count: 4, data: 0}, [
"bbb",
"ba ",
"   "
], ['a',ItemID.钉钉锭,0,'b',353,0]);


IDRegistry.genItemID("龙王");
Item.createFoodItem("龙王", "龙王", {name:"龙王"}, {food:6});

IDRegistry.genItemID("龙王-透");
Item.createFoodItem("龙王-透", "龙王-透", {name:"龙王-透"}, {food:9});

//钉钉物品
IDRegistry.genItemID("钉钉锭");

Item.createItem("钉钉锭", "钉钉锭", {
    name : "钉钉锭", meta : 0 
});

Recipes.addShaped({id: ItemID.钉钉锭, count: 1, data: 0}, [
"ab ",
"   ",
"   "
], ['a',ItemID.钉钉煤,0,'b',BlockID.钉钉矿,0]);


IDRegistry.genItemID("钉钉煤");

Item.createItem("钉钉煤", "钉钉煤", {
    name : "钉钉煤", meta : 0 
});


//钉钉矿
IDRegistry.genBlockID("钉钉矿");

Block.createBlockWithRotation("钉钉矿", [
	{name: "钉钉矿", texture: [["钉钉矿", 0], ["钉钉矿", 0], ["钉钉矿", 0], ["钉钉矿",0], ["钉钉矿", 0], ["钉钉矿", 0]], inCreative: true}]);

ToolAPI.registerBlockMaterial(BlockID.钉钉矿, "stone");

Block.registerDropFunction("钉钉矿", function(coords, id, data, diggingLevel, toolLevel){
 if(diggingLevel>2){
 return [[BlockID.钉钉矿, 1, 0]];}
 else{
  return [[0, 0, 0]]
 }
});


//钉钉矿生成
function addnewore(id,data,count,max,min,heighest,lowest){
var amount=Math.floor(Math.random() * (max - min + 1)) + min;
Callback.addCallback("GenerateChunkUnderground", function(chunkX, chunkZ){
for(var i = 0; i < count; i++){
var coords = GenerationUtils.randomCoords(chunkX, chunkZ, lowest, heighest);
GenerationUtils.generateOre(coords.x, coords.y, coords.z, id, data, amount);
}});
};
addnewore(BlockID.钉钉矿,0,18,10,5,180,10)


//合成
Recipes.addShaped({id:BlockID.钉钉块,count:1,data:0},[
"aaa",
"aaa",
"aaa"
],['a',ItemID.钉钉锭,0]);



Recipes.addShaped({id: ItemID.钉钉锭, count: 9, data: 0}, [
"   ",
" a ",
"   "
], ['a',BlockID.钉钉块,0]);


Recipes.addShaped({id: ItemID.钉钉锭, count: 1, data: 0}, [
"ab ",
"   ",
"   "
], ['a',ItemID.钉钉煤,0,'b',BlockID.钉钉矿,0]);


Recipes.addShaped({id: ItemID.钉钉煤, count: 4, data: 0}, [
"cbc",
"bab",
"cbc"
], ['a',263,0,'b',50,0,'c',280,0]);


//钉钉护具
IDRegistry.genItemID("钉钉战盔");
Item.createArmorItem("钉钉战盔", "钉钉战盔", {name: "钉钉战盔"}, {
    type: "helmet",
    armor:9,
    durability:250,
    texture: "钉钉护具/钉钉战盔.png"
});
IDRegistry.genItemID("钉钉战盔");

Recipes.addShaped({id: ItemID.钉钉战盔, count: 1, data: 0}, [
"aaa",
"a a",
"   "
	], ['a',ItemID.钉钉锭,0]);





//钉钉武器


//file:其它.js
importLib("ToolType", "*");


IDRegistry.genItemID("钉钉剑");
Item.createItem("钉钉剑", "钉钉剑", {name: "钉钉剑",meta: 0},{stack:1});

ToolAPI.addToolMaterial("a", {durability: 500, damage:15,level:10,efficiency:9});


ToolType.a = {
damage: 15,
		blockTypes: ["fibre", "plant","wood","stone","dirt"],
		onAttack: function(item){
			if(item.data > Item.getMaxDamage(item.id)){
				item.id = item.data = item.count = 0;
			}
		},
		calcDestroyTime: function(item, coords, block, params, destroyTime, enchant){
			if(block.id==30){return 0.08;}
			if(block.id==35){return 0.05;}
			var material = ToolAPI.getBlockMaterial(block.id) || {};
			if(material.name=="fibre" || material.name=="plant"){
				return params.base/1.5;
			}
			return destroyTime;
		}
};



ToolAPI.setTool(ItemID.钉钉剑, "diamond",ToolType.a);


Item.setMaxDamage(ItemID.钉钉剑,1000);


Recipes.addShaped({id: ItemID.钉钉剑, count: 1, data: 0}, [
"a  ",
"a  ",
"b  "
], ['a',ItemID.钉钉锭,0,'b',280,0]);


//杂物
IDRegistry.genItemID("龙王经验之水");

Item.createItem("龙王经验之水", "龙王经验之水", {
    name : "龙王经验之水", meta : 0 
});


Recipes.addShaped({id: ItemID.龙王经验之水, count: 8, data: 0}, [
"   ",
" a ",
"   "
], ['a',325,8]);

IDRegistry.genItemID("龙王之怒");

Item.createItem("龙王之怒", "龙王之怒", {
    name : "龙王之怒", meta : 0 
});


Recipes.addShaped({id: ItemID.龙王之怒, count: 1, data: 0}, [
"dbd",
"cac",
"dbd"
], ['a',38,0,'b',287,0,'c',339,0,'d',50,0]);


//龙王合成

Recipes.addShaped({id:ItemID.龙王,count:3,data:0},[
"aba",
"aaa",
"aaa"
],['a',ItemID.龙王经验之水,0,'b',ItemID.龙王之怒,0]);


//烧制
Recipes.addFurnace(BlockID.钉钉矿,ItemID.钉钉锭,0);




