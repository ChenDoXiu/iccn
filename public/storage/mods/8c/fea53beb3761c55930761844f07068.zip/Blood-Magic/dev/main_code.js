Callback.addCallback("LevelLoaded",function(){
	Game.message("Mod加载完成，SlenderPE, vk讨论组: https://vk.com/blood_magic_pe");
	Game.message("Mod was created by SlenderPE, group of mod: https://vk.com/blood_magic_pe");
});
/*var LpModified = __config__.access("blood_altar.LpModified");*/