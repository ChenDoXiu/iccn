Callback.addCallback("LevelLoaded",function(){
	Game.message("血魔法2 Mod加载完成，SlenderPE, vk讨论组: https://vk.com/blood_magic_pe");
	Game.message("Blood Magic 2 Mod was created by SlenderPE, group of mod: https://vk.com/blood_magic_pe");
});
/*var LpModified = __config__.access("blood_altar.LpModified");*/