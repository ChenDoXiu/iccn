IDRegistry.genItemID("weakBloodShard");
Item.createItem("weakBloodShard", "Weak Blood Shard", {name: "weak_blood_shard", meta: 0}, {stack: 64});
Translation.addTranslation("Weak Blood Shard",{ru: "Ослабленый Осколок Души",zh:"§c§l[虚弱]气血碎片"});
//TODO сделать его выпадение

