
/*
BUILD INFO:
  dir: dev
  target: main.js
  files: n
*/
//钉钉块
IDRegistry.genBlockID("Dingtalk_Block");
Block.createBlockWithRotation("Dingtalk_Block", [
	{name: "Dingtalk_Block", texture: [["Dingtalk_Block", 0], ["Dingtalk_Block", 0], ["Dingtalk_Block", 0], ["Dingtalk_Block", 0], ["Dingtalk_Block", 0], ["Dingtalk_Block", 0]], inCreative: true}
]);
ToolAPI.registerBlockMaterial(BlockID.Dingtalk_Block, "stone");


//食物
IDRegistry.genItemID("Dingtalk_Sugar");
Item.createFoodItem("Dingtalk_Sugar", "Dingtalk_Sugar", {name:"Dingtalk_Sugar"}, {food:4});


Recipes.addShaped({id: ItemID.Dingtalk_Sugar, count: 4, data: 0}, [
"bbb",
"ba ",
"   "
], ['a',ItemID.Dingtalk_Ingot,0,'b',353,0]);


IDRegistry.genItemID("Dragon_King");
Item.createFoodItem("Dragon_King", "Dragon_King", {name:"Dragon_King"}, {food:6});

IDRegistry.genItemID("Dragon_King_Naked");
Item.createFoodItem("Dragon_King_Naked", "Dragon_King_Naked", {name:"Dragon_King_Naked"}, {food:9});

//钉钉物品
IDRegistry.genItemID("Dingtalk_Ingot");

Item.createItem("Dingtalk_Ingot", "Dingtalk_Ingot", {
    name : "Dingtalk_Ingot", meta : 0 
});

Recipes.addShaped({id: ItemID.Dingtalk_Ingot, count: 1, data: 0}, [
"ab ",
"   ",
"   "
], ['a',ItemID.Dingtalk_Coal,0,'b',BlockID.Dingtalk_ore,0]);


IDRegistry.genItemID("Dingtalk_Coal");

Item.createItem("Dingtalk_Coal", "Dingtalk_Coal", {
    name : "Dingtalk_Coal", meta : 0 
});


//钉钉矿生成
IDRegistry.genBlockID("Dingtalk_ore");

Block.createBlockWithRotation("Dingtalk_ore", [
	{name: "Dingtalk_ore", texture: [["Dingtalk_ore", 0], ["Dingtalk_ore", 0], ["Dingtalk_ore", 0], ["Dingtalk_ore",0], ["Dingtalk_ore", 0], ["Dingtalk_ore", 0]], inCreative: true}]);

ToolAPI.registerBlockMaterial(BlockID.Dingtalk_ore, "stone");

Block.registerDropFunction("Dingtalk_ore", function(coords, id, data, diggingLevel, toolLevel){
 if(diggingLevel>2){
 return [[BlockID.Dingtalk_ore, 1, 0]];}
 else{
  return [[0, 0, 0]]
 }
});


//Dingtalk_ore生成
function addnewore(id,data,count,max,min,heighest,lowest){
var amount=Math.floor(Math.random() * (max - min + 1)) + min;
Callback.addCallback("GenerateChunkUnderground", function(chunkX, chunkZ){
for(var i = 0; i < count; i++){
var coords = GenerationUtils.randomCoords(chunkX, chunkZ, lowest, heighest);
GenerationUtils.generateOre(coords.x, coords.y, coords.z, id, data, amount);
}});
};
addnewore(BlockID.Dingtalk_ore,0,18,10,5,180,10)


//合成
Recipes.addShaped({id:BlockID.Dingtalk_Block,count:1,data:0},[
"aaa",
"aaa",
"aaa"
],['a',ItemID.Dingtalk_Ingot,0]);



Recipes.addShaped({id: ItemID.Dingtalk_Ingot, count: 9, data: 0}, [
"   ",
" a ",
"   "
], ['a',BlockID.Dingtalk_Block,0]);


Recipes.addShaped({id: ItemID.Dingtalk_Ingot, count: 1, data: 0}, [
"ab ",
"   ",
"   "
], ['a',ItemID.Dingtalk_Coal,0,'b',BlockID.Dingtalk_ore,0]);


Recipes.addShaped({id: ItemID.Dingtalk_Coal, count: 4, data: 0}, [
"cbc",
"bab",
"cbc"
], ['a',263,0,'b',50,0,'c',280,0]);


//钉钉护具
IDRegistry.genItemID("Dingtalk_Helmet");
Item.createArmorItem("Dingtalk_Helmet", "Dingtalk_Helmet", {name: "Dingtalk_Helmet"}, {
    type: "helmet",
    armor:9,
    durability:250,
    texture: "钉钉护具/Dingtalk_Helmet.png"
});
IDRegistry.genItemID("Dingtalk_Helmet");

Recipes.addShaped({id: ItemID.Dingtalk_Helmet, count: 1, data: 0}, [
"aaa",
"a a",
"   "
	], ['a',ItemID.Dingtalk_Ingot,0]);





//钉钉武器


//file:其它.js
importLib("ToolType", "*");


IDRegistry.genItemID("Dingtalk_Sword");
Item.createItem("Dingtalk_Sword", "Dingtalk_Sword", {name: "Dingtalk_Sword",meta: 0},{stack:1});

ToolAPI.addToolMaterial("a", {durability: 500, damage:15,level:10,efficiency:9});


ToolType.a = {
damage: 15,
		blockTypes: ["fibre", "plant","wood","dirt"],
		onAttack: function(item){
			if(item.data > Item.getMaxDamage(item.id)){
				item.id = item.data = item.count = 0;
			}
		},
		calcDestroyTime: function(item, coords, block, params, destroyTime, enchant){
			if(block.id==30){return 0.08;}
			if(block.id==35){return 0.05;}
			var material = ToolAPI.getBlockMaterial(block.id) || {};
			if(material.name=="fibre" || material.name=="plant"){
				return params.base/1.5;
			}
			return destroyTime;
		}
};



ToolAPI.setTool(ItemID.Dingtalk_Sword, "diamond",ToolType.a);


Item.setMaxDamage(ItemID.Dingtalk_Sword,1000);


Recipes.addShaped({id: ItemID.Dingtalk_Sword, count: 1, data: 0}, [
"a  ",
"a  ",
"b  "
], ['a',ItemID.Dingtalk_Ingot,0,'b',280,0]);


//杂物
IDRegistry.genItemID("Dragon_King_Experience_Water");

Item.createItem("Dragon_King_Experience_Water", "Dragon_King_Experience_Water", {
    name : "Dragon_King_Experience_Water", meta : 0 
});


Recipes.addShaped({id: ItemID.Dragon_King_Experience_Water, count: 8, data: 0}, [
"   ",
" a ",
"   "
], ['a',325,8]);

IDRegistry.genItemID("Dragon_King_Anger");

Item.createItem("Dragon_King_Anger", "Dragon_King_Anger", {
    name : "Dragon_King_Anger", meta : 0 
});


Recipes.addShaped({id: ItemID.Dragon_King_Anger, count: 1, data: 0}, [
"dbd",
"cac",
"dbd"
], ['a',38,0,'b',287,0,'c',339,0,'d',50,0]);


//龙王合成

Recipes.addShaped({id:ItemID.Dragon_King,count:3,data:0},[
"aba",
"aaa",
"aaa"
],['a',ItemID.Dragon_King_Experience_Water,0,'b',ItemID.Dragon_King_Anger,0]);


//烧制
Recipes.addFurnace(BlockID.Dingtalk_ore,ItemID.Dingtalk_Ingot,0);


//翻译
Translation.addTranslation("Dingtalk_ore", {zh:"钉钉矿"});
Translation.addTranslation("Dingtalk_Block", {zh:"钉钉块"});
Translation.addTranslation("Dingtalk_Sword", {zh:"钉钉剑"});
Translation.addTranslation("Dingtalk_Helmet", {zh:"钉钉头盔"});
Translation.addTranslation("Dragon_King_Experience_Water", {zh:"龙王经验之水"});
Translation.addTranslation("Dragon_King_Anger", {zh:"龙王之怒"});
Translation.addTranslation("Dingtalk_Coal", {zh:"钉钉煤"});
Translation.addTranslation("Dingtalk_Ingot", {zh:"钉钉锭"});
Translation.addTranslation("Dragon_King", {zh:"龙王"});
Translation.addTranslation("Dragon_King_Naked", {zh:"龙王 透"});
Translation.addTranslation("Dingtalk_Sugar", {zh:"钉钉糖"});