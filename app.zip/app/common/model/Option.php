<?php

namespace app\common\model;
use think\Model;
/**
 * Class Option
 * @author chenduxiu
 */
class Option extends Model
{
}
