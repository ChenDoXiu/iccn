<?php
//其他功能权限设定
return [
    "admin/article/add" => 3,
    "admin/audit/approved" => 4,
    "admin/audit/dis"   => 4,
    "admin/brush/indexupdate" => 5,
    "admin/brush/bananaupdate" => 5,
    "admin/brush/savemenu" => 5,
    "admin/brush/updatemenu" => 5,
    "admin/brush/removemenu" => 5,
    "admin/brush/savefooter" => 5,
    "admin/comment/delete" => 1,
    "admin/plate/save" => 4,
    "admin/plate/update" => 4,   
    "admin/plate/dalete" => 4,
    "admin/user/upphoto" => 1,
    "admin/user/upinfo" => 1,   
    "admin/user/save" => 5,    
    "admin/user/uppass" => 1, 
    "admin/user/update" => 5, 
];
